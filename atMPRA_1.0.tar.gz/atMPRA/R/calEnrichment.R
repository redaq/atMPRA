calEnrichment <-
function(resultAll, threshold=0.05)
{		message("Compute enrichment in allele-imbalanced SNPs among significant results... \n")
		resultAll2 = data.frame(simN = resultAll$simN, resInput = resultAll$resInput, resultAll[,-c(1,5)])
		enrichment=c()
		for(i in 3:ncol(resultAll2))
		{	dataFrame = resultAll2[resultAll2$resInput >=0 & resultAll2[,i] >= 0 & !is.na(resultAll2$resInput) & !is.na(resultAll2[,i]),]
			ddtemp = dataFrame[dataFrame[,i]<threshold,]
			MWP = data.frame(method = colnames(resultAll2)[i], q=sum(ddtemp$resInput<threshold), m=nrow(ddtemp), enrichP=phyper(q=sum(ddtemp$resInput<threshold)-1, m=nrow(ddtemp), n=nrow(dataFrame)-nrow(ddtemp), k=sum(dataFrame$resInput<threshold), lower.tail=F))
			enrichment =rbind(enrichment, MWP)
		}
		return(enrichment)
}
